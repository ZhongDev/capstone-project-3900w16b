export type manageTableHelpCall = {
  tableId: number;
  numOccurrence: number;
};
