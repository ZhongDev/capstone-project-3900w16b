import request from "axios";
request.defaults.withCredentials = true;

export default request;
